
/*
Name: Guan Ying Goh
Course: Project 1B
Date: 2/27/23
Instructor: G. Maryash
*/

#include <iostream>
#include <string>
#include <fstream>
using namespace std;
string prefix;
const int g_MAX_WORDS = 1000;
int g_word_count = 0;
string g_words[g_MAX_WORDS];
string g_definitions[g_MAX_WORDS];
string g_pos[g_MAX_WORDS];
string word;
int getIndex(string word);
string getDefinition(string word);
string getPOS(string word);
int countPrefix(string prefix);

void readWords(string filename)
{
    ifstream fin(filename);
    if (fin.fail()) {
        cerr << "File cannot be opened for reading." << endl;
        exit(1); 
    }
    string words,definitions, pos;
    while(fin >> words >> pos >> definitions)
    {
        getline(fin, definitions);
        g_words[g_word_count]=words;
        g_pos[g_word_count]=pos;
        g_definitions[g_word_count]=definitions.substr(1);
        g_word_count++;
    }
    fin.close();
}
int getIndex(string word)
{
    bool equal = false;
    for (int i=0;i<g_word_count;i++)
    {
        if(word==g_words[i])
        {
            equal = true;
            return (i);
        }
    }
    if (!equal)
    {
        return -1;
    }
    return 0;
}
string getDefinition(string word)
{
    bool equal = false;
    for(int i=0;i<g_word_count;i++)
    {
        if(word==g_words[i])
        {
            equal = true;
            return g_definitions[i];
        }
    }
    if (!equal)
    {
        return "NOT_FOUND";
    }
    return 0;
}

string getPOS(string word)
{
    bool equal = false;
    for (int i = 0; i < g_word_count ; i++)
    {
        if(word==g_words[i])
        {
            equal = true;
            return g_pos[i];
        }
    }
    if (!equal)
    {
        return "NOT_FOUND";
    }
    return 0;
}

int countPrefix(string prefix)
{
    int count = 0;
    for (int i=0 ; i<g_word_count ; i++)
    {
        string findprefix = g_words[i].substr(0,prefix.length());
        if(findprefix==prefix)
        {
            count = count +1;
        }
    }
    return count;
    return 0;
}
