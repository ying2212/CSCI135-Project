/*
Name: Guan Ying Goh
Course: Project 1C
Date: 3/1/23
Instructor: G. Maryash
*/

#include <iostream>
#include <string>
#include <fstream>
using namespace std;
const int g_MAX_WORDS = 1000;
int g_word_count = 0;
string g_words[g_MAX_WORDS];
string g_definitions[g_MAX_WORDS];
string g_pos[g_MAX_WORDS];
string word;
int getIndex(string word);
string getDefinition(string word);
string getPOS(string word);
int countPrefix(string prefix);
bool addWord(string word, string definition, string pos);
bool editWord(string word, string definition, string pos);
bool removeWord(string word);

void readWords(string filename)
{
    ifstream fin(filename);
    if (fin.fail()) {
        cerr << "File cannot be opened for reading." << endl;
        exit(1); 
    }
    string words,definitions, pos;
    while(fin >> words >> pos >> definitions)
    {
        getline(fin, definitions);
        g_words[g_word_count]=words;
        g_pos[g_word_count]=pos;
        g_definitions[g_word_count]=definitions.substr(1);
        g_word_count++;
    }
    fin.close();
}
int getIndex(string word)
{
    bool equal = false;
    for (int i=0;i<g_word_count;i++)
    {
        if(word==g_words[i])
        {
            equal = true;
            return (i);
        }
    }
    if (!equal)
    {
        return -1;
    }
    return 0;
}
string getDefinition(string word)
{
    bool equal = false;
    for(int i=0;i<g_word_count;i++)
    {
        if(word==g_words[i])
        {
            equal = true;
            return g_definitions[i];
        }
    }
    if (!equal)
    {
        return "NOT_FOUND";
    }
    return 0;
}

string getPOS(string word)
{
    bool equal = false;
    for (int i = 0; i < g_word_count ; i++)
    {
        if(word==g_words[i])
        {
            equal = true;
            return g_pos[i];
        }
    }
    if (!equal)
    {
        return "NOT_FOUND";
    }
    return 0;
}

int countPrefix(string prefix)
{
    int count = 0;
    for (int i=0 ; i<g_word_count ; i++)
    {
        string findprefix = g_words[i].substr(0,prefix.length());
        if(findprefix==prefix)
        {
            count = count +1;
        }
    }
    return count;
    return 0;
}
bool addWord(string word, string definition, string pos)
{
	if(g_word_count >= g_MAX_WORDS)
	{
		return false;
	}
	for (int i=0;i<g_word_count;i++)
	{
		if(g_words[i]==word)
		{
			return false;
		}
	}
	g_words[g_word_count] = word;
	g_pos[g_word_count] = pos;
	g_definitions[g_word_count] = definition;
	g_word_count = g_word_count +1;
	return true;
}

bool editWord(string word, string definition, string pos)
{
    int size = sizeof(g_words)/sizeof(g_words[0]);
    bool found = false;
    for (int i=0;i<size;i++)
    {
        if(word==g_words[i])
        {
            g_definitions[i]=definition;
            g_pos[i]=pos;
            found = true;
            return true;
        }
    }
    return false;
}               
bool removeWord(string word)
{	
	for(int i =0;i<g_word_count;i++)
	{
		if(g_words[i] == word)
		{
			for(int j = i ; j<g_word_count-1; j++)
			{
				g_words[j] = g_words[j+1];
				g_definitions[j] = g_definitions[j+1];
				g_pos[j]=g_pos[j+1];

			}
			g_words[g_word_count-1]="";
			g_definitions[g_word_count-1]="";
			g_pos[g_word_count-1]="";
			g_word_count--;
			return true;
			
		}
	}
	return false;
}


