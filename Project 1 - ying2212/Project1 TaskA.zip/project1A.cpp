

/*
Name: Guan Ying Goh
Course: Project 1A
Date: 2/25/23
Instructor: G. Maryash
A regular dictionary contains the words and the definitions. In addition to the words and the definitions, 
we will also store the part-of-speech (pos). The words, definitions and pos are going to be stored in Arrays.
Use these global-variables in your code outside main() function
*/
/*
    @param            :   The string with the `filename'
    @post             :   Reads the words, definitions
                          pos into the global-arrays 
                          and set the value of `g_word_count`
                          to the number of words read
*/

#include <iostream>
#include <string>
#include <fstream>
using namespace std;

const int g_MAX_WORDS = 1000;
int g_word_count = 0;
string g_words[g_MAX_WORDS];
string g_definitions[g_MAX_WORDS];
string g_pos[g_MAX_WORDS];

void readWords(string filename)
{
    ifstream fin(filename);
    if (fin.fail()) {
        cerr << "File cannot be opened for reading." << endl;
        exit(1); 
    }
    string words,definitions, pos;
    while(fin >> words >> pos >> definitions)
    {
        getline(fin, definitions);
        g_words[g_word_count]=words;
        g_pos[g_word_count]=pos;
        g_definitions[g_word_count]=definitions.substr(1);
        g_word_count++;
    }       
    cout << words << " " << pos << " : " <<  definitions.substr(1) << endl;
    fin.close();
}
    
