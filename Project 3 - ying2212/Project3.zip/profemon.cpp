 /*
Name: Guan Ying Goh
Date: May 3,2023
Instructor: G.Maryash
The header file of the Profemon class must have an enumeration type called “Specialty” with three possible values: 
ML, SOFTWARE, and HARDWARE in this exact order. The enum should be defined outside the class.
*/

#include "profemon.hpp"


//Initialize name to Undefined
Profemon::Profemon()
{
    this->p_name = "Undefined";
}

//initialize the name,health,specialty,exp,level
Profemon::Profemon(std::string name, double max_health, Specialty specialty)
{
    this->p_name = name;
    this->max_health_level = max_health;
    this->p_specialty = specialty;
    this->p_required_experience = 50;
    this->p_current_experience = 0;
    this->p_level = 0;
}

//return name
std::string Profemon::getName()
{
    return p_name;
}

//return Specialty
Specialty Profemon::getSpecialty()
{
    return p_specialty;
}

//return level
int Profemon::getLevel()
{
    return p_level;
}

//return health
double Profemon::getMaxHealth()
{
    return max_health_level;
}

//set p_name equal to the name
void Profemon::setName(std::string name)
{
    this->p_name = name;
}

//find the level accor to the specialty
void Profemon::levelUp(int exp)
{
    while(exp>=p_required_experience-p_current_experience)
    {
        exp = exp - (p_required_experience-p_current_experience);
        p_current_experience = 0;
        p_level = p_level +1;
        switch(p_specialty)
        {
            case ML:
                p_required_experience=p_required_experience+10;
                break;
            case SOFTWARE:
                p_required_experience=p_required_experience+15;
                break;
            case HARDWARE:
                p_required_experience=p_required_experience+20;
                break;
            default:
                break;
        }
    }
    p_current_experience += exp;
}

//return true if the skill slot is valid 
bool Profemon::learnSkill(int slot, Skill skill)
{
    if(slot < 0 || slot > 2)
    {
        return false;
    }
    else if(skill.getSpecialty() != p_specialty)
    {
        return false;
    }
    skills[slot] = skill;
    return true;
}


void Profemon::printProfemon(bool print_skills)
{
    std::string spec;
    if(p_specialty == 0){
        spec = "ML";
    }
    else if(p_specialty == 1){
        spec = "SOFTWARE";
    }
    else {
        spec = "HARDWARE";
    }
    
    std::cout << p_name << " [" << spec << "] | lvl " << p_level << " | exp " << p_current_experience
    << "/" << p_required_experience << " | hp " << max_health_level << std::endl;
    //print_skills = true;
    if(print_skills)
    {
        for(int i = 0; i< 3 ; i++)
        {
            if(skills[i].getName() != "Undefined")
            {
                std::cout << "    " << skills[i].getName() << " [" << skills[i].getTotalUses() << "] : "
                << skills[i].getDescription() << std::endl;
            }
        }
    }
}

