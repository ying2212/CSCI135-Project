/*
Name: Guan Ying Goh
Date: May 3,2023
Instructor: G.Maryash
The header file of the Profemon class must have an enumeration type called “Specialty” with three possible values: 
ML, SOFTWARE, and HARDWARE in this exact order. The enum should be defined outside the class.
*/
#pragma once
#include <iostream>
#include <string>

class Skill {
  private:
    std::string s_name;
    std::string s_description;
    int s_num_skill;
    int s_specialty;

  public:
    Skill();
    Skill(std::string name, std::string description, int specialty, int uses);
    std::string getName();
    std::string getDescription();
    int getTotalUses();
    int getSpecialty();
    void setName(std::string name);
    void setDescription(std::string description);
    void setTotalUses(int uses);
    bool setSpecialty(int specialty);
};


