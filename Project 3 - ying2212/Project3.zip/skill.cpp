 /*
Name: Guan Ying Goh
Date: May 3,2023
Instructor: G.Maryash
The header file of the Profemon class must have an enumeration type called “Specialty” with three possible values: 
ML, SOFTWARE, and HARDWARE in this exact order. The enum should be defined outside the class.
*/


#include "skill.hpp"
#include <iostream>
#include <string>
using namespace std;

Skill::Skill()
{
    this->s_name = "Undefined";
    this->s_description = "Undefined";
    this->s_specialty = -1;
    this->s_num_skill = -1;
}

Skill::Skill(std::string name, std::string description, int specialty, int uses)
{
    this->s_name = name;
    this->s_description = description;
    this->s_specialty = specialty;
    this->s_num_skill = uses;
}

std::string Skill::getName()
{
    return s_name;
}

std::string Skill::getDescription()
{
    return s_description;
}

int Skill::getTotalUses()
{
    return s_num_skill;
}

int Skill::getSpecialty()
{
    return s_specialty;
}

void Skill::setName(std::string name)
{
    this->s_name = name;
}

void Skill::setDescription(std::string description)
{
    this->s_description = description;
}

void Skill::setTotalUses(int uses)
{
    this->s_num_skill = uses;
}

bool Skill::setSpecialty(int specialty)
{
    
    if(specialty==0 ||specialty==1 || specialty==2)
    {
        this->s_specialty = specialty;
        return true;
    }
    else
    {
        return false;
    }
}
