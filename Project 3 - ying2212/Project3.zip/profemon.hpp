 /*
Name: Guan Ying Goh
Date: May 3,2023
Instructor: G.Maryash
The header file of the Profemon class must have an enumeration type called “Specialty” with three possible values: 
ML, SOFTWARE, and HARDWARE in this exact order. The enum should be defined outside the class.
*/


#pragma once
#include <string>
#include "skill.hpp"

enum Specialty{ML, SOFTWARE, HARDWARE};

// static const char *enum_to_string[] ={ 
//     "ML", 
//     "SOFTWARE", 
//     "HARDWARE"
// };

class Profemon{
  private:
    std::string p_name;
    int p_level;
    int p_required_experience;
    int p_current_experience;
    double max_health_level;
    Specialty p_specialty;
    Skill skills[3];
  public:
    Profemon();
    Profemon(std::string name, double max_health, Specialty specialty);
    std::string getName();
    Specialty getSpecialty();
    int getLevel();
    double getMaxHealth();
    void setName(std::string name);
    void levelUp(int exp);
    bool learnSkill(int slot, Skill skill);
    void printProfemon(bool print_skills);
};




