
/*
Name: Guan Ying Goh
Instructor: G.Maryash
Date: 4/4/23
Title: Project 2
*/

#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <stdlib.h>
using namespace std;
int g_curr_size = 2;
int g_number_of_songs = 0;
string *g_song_names = new string[g_curr_size];
string *g_artist_names = new string[g_curr_size];
int *g_song_durations = new int[g_curr_size];
string *g_genres = new string[g_curr_size];

void allocateNew();
void allocateNew()
{
    int size = g_curr_size * 2;
    string *song_names= new string[size];
    string *artist_names=new string[size];
    int *song_durations=new int[size];
    string *genres=new string[size];
    for(int i = 0; i<g_curr_size; i++)
    {
        song_names[i]=g_song_names[i];
        artist_names[i]=g_artist_names[i];
        song_durations[i]=g_song_durations[i];
        genres[i]=g_genres[i];
    }
    delete[] g_song_names;
    delete[] g_artist_names;
    delete[] g_song_durations;
    delete[] g_genres;
    g_song_names = song_names;
    g_artist_names = artist_names ;
    g_song_durations = song_durations;
    g_genres = genres;
    g_curr_size = size;
}
void readSongs(string filename);
void readSongs(string filename){
    ifstream fin(filename);
    if(fin.fail()){
        cerr << "File cannot opened for reading" << endl;
        exit(1);
    }
    string song_name, artist_name, genre, duration_prelim,junk;
    int duration;

    while (fin) {

        if(g_number_of_songs == g_curr_size)
        {
            allocateNew();
        }
        getline(fin, song_name, ':');
        getline(fin, artist_name, '-');
        getline(fin, genre, '-');
        getline(fin, duration_prelim, ' ');
        getline(fin, junk);

        duration = stoi(duration_prelim);

        g_song_names[g_number_of_songs] = song_name;
        g_artist_names[g_number_of_songs] = artist_name;
        g_song_durations[g_number_of_songs] = duration;
        g_genres[g_number_of_songs] = genre;

        g_number_of_songs++;
    }
    g_number_of_songs = g_number_of_songs-1;
    fin.close();

}
string * getGenreSongs(string genre, int &genreCount);
string * getGenreSongs(string genre, int &genreCount)
{
    string *genreSong = new string[g_number_of_songs];
    int s1 = g_number_of_songs;
    genreCount = 0;
    for(int i = 0; i<s1 ; i++)
    {
        if(g_genres[i]==genre)
        {
            genreSong[genreCount] = g_song_names[i];
            genreCount++;
        }
    }
    return genreSong;
}

string * getSongsFromDuration(int duration, int &durationsCount, int filter);
string * getSongsFromDuration(int duration, int &durationsCount, int filter)
{
    string *number = new string[g_number_of_songs];
    durationsCount= 0;
    for(int i = 0; i<g_number_of_songs;i++)
    {
        if(filter==0 && g_song_durations[i] > duration)
        {
            number[durationsCount] = g_song_names[i];
            durationsCount++;
        }
        else if(filter ==1 && g_song_durations[i] < duration)
        {
            number[durationsCount] = g_song_names[i];
            durationsCount++;
        }
        else if(filter ==2 && g_song_durations[i] == duration)
        {
            number[durationsCount] = g_song_names[i];
            durationsCount++;
        }
    }
    return number;
}

string * getUniqueArtists(int &uniqueCount);
string * getUniqueArtists(int &uniqueCount){
    string *result = new string[g_number_of_songs];
    uniqueCount = 0;
    for(int i = 0; i < g_number_of_songs; i++){
        bool isUnique = true ;
        for(int j = 0; j < uniqueCount; j++){
            if(g_artist_names[i] == result[j]){
                isUnique = false;
                break;
            }
        }
        if(isUnique){
            result[uniqueCount] = g_artist_names[i];
            uniqueCount++;
        }
    }
    return result;
}

string getFavoriteArtist();
string getFavoriteArtist()
{
    if(g_number_of_songs==0)
    {
        return "NONE";
    }
    int maxCount = 1;
    string artist = g_artist_names[0];
    for(int i = 0; i < g_number_of_songs ; i++)
    {
        int count = 1;
        for(int j = 0; j < g_number_of_songs ; j++)
        {
            for(int j = i+1; j< g_number_of_songs; j++)
            {
                if(g_artist_names[i]==g_artist_names[j])
                {
                    count++;
                }
            }
            if(count > maxCount)
            {
                maxCount = count;
                artist = g_artist_names[i];
            }
        }
    }
        return artist;
}

