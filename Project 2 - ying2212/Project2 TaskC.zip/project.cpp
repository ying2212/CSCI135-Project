/*
Name: Guan Ying Goh
Instructor: G.Maryash
Date: 4/4/23
Title: Project 2
*/

#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <stdlib.h>
using namespace std;

class Song
{
    public:
        string name;
        string artist;
        int duration;
        string genre;
};

int g_capacity = 2;
int g_size = 0;
Song *g_songs = new Song[g_capacity];

void allocateNew();
void allocateNew()
{
    int new_size = g_capacity * 2;
    Song *new_song= new Song[new_size];
    for(int i = 0; i<g_capacity; i++)
    {
        new_song[i]=g_songs[i];
    }
    delete[] g_songs;
    g_songs = new_song;
    g_capacity = new_size;
}


void readSongs(string filename);
void readSongs(string filename){
    ifstream fin(filename);
    if(fin.fail()){
        cerr << "File cannot opened for reading" << endl;
        exit(1);
    }
    string song_name, artist_name, genre, duration_prelim,junk;
    int duration;

    while (fin) {

        if(g_size == g_capacity)
        {
            allocateNew();
        }
        getline(fin, song_name, ':');
        getline(fin, artist_name, '-');
        getline(fin, genre, '-');
        getline(fin, duration_prelim, ' ');
        getline(fin, junk);

        duration = stoi(duration_prelim);

        g_songs[g_size].name = song_name;
        g_songs[g_size].artist = artist_name;
        g_songs[g_size].duration = duration;
        g_songs[g_size].genre = genre;

        g_size++;
    }
    g_size = g_size-1;
    fin.close();

}

Song * getGenreSongs(string genre, int &genreCount);
Song * getGenreSongs(string genre, int &genreCount)
{
    Song *genreSong = new Song[g_size];
    int s1 = g_size;
    genreCount = 0;
    for(int i = 0; i<s1 ; i++)
    {
        if(g_songs[i].genre==genre)
        {
            genreSong[genreCount] = g_songs[i];
            genreCount++;
        }
    }
    return genreSong;
}

Song * getSongsFromDuration(int duration, int &durationsCount, int filter);
Song * getSongsFromDuration(int duration, int &durationsCount, int filter)
{
    Song *number = new Song[g_size];
    durationsCount= 0;
    for(int i = 0; i<g_size;i++)
    {
        if(filter==0 && g_songs[i].duration > duration)
        {
            number[durationsCount] = g_songs[i];
            durationsCount++;
        }
        else if(filter ==1 && g_songs[i].duration < duration)
        {
            number[durationsCount] = g_songs[i];
            durationsCount++;
        }
        else if(filter ==2 && g_songs[i].duration == duration)
        {
            number[durationsCount] = g_songs[i];
            durationsCount++;
        }
    }
    return number;
}

string * getUniqueArtists(int &uniqueCount);
string * getUniqueArtists(int &uniqueCount)
{
    string *result = new string[g_size];
    uniqueCount = 0;
    for(int i = 0; i < g_size; i++){
        bool isUnique = true ;
        for(int j = 0; j < uniqueCount; j++){
            if(g_songs[i].artist == result[j]){
                isUnique = false;
                break;
            }
        }
        if(isUnique){
            result[uniqueCount] = g_songs[i].artist;
            uniqueCount++;
        }
    }
    return result;
}

string getFavoriteArtist();
string getFavoriteArtist()
{
    if(g_size==0)
    {
        return "NONE";
    }
    int maxCount = 1;
    string artist = g_songs[0].artist;
    for(int i = 0; i < g_size ; i++)
    {
        int count = 1;
        for(int j = 0; j < g_size ; j++)
        {
            for(int j = i+1; j< g_size; j++)
            {
                if(g_songs[i].artist==g_songs[j].artist)
                {
                    count++;
                }
            }
            if(count > maxCount)
            {
                maxCount = count;
                artist = g_songs[i].artist;
            }
        }
    }
        return artist;
}

