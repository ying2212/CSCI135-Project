
/*
Name: Guan Ying Goh
Instructor: G.Maryash
Date: 4/4/23
Title: Project 2
*/

#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <stdlib.h>
using namespace std;
int g_curr_size = 2;
int g_number_of_songs = 0;
string *g_song_names = new string[g_curr_size];
string *g_artist_names = new string[g_curr_size];
int *g_song_durations = new int[g_curr_size];
string *g_genres = new string[g_curr_size];

void allocateNew();
void allocateNew()
{
    int size = g_curr_size * 2;
    string *song_names= new string[size];
    string *artist_names=new string[size];
    int *song_durations=new int[size];
    string *genres=new string[size];
    for(int i = 0; i<g_curr_size; i++)
    {
        song_names[i]=g_song_names[i];
        artist_names[i]=g_artist_names[i];
        song_durations[i]=g_song_durations[i];
        genres[i]=g_genres[i];
    }
    delete[] g_song_names;
    delete[] g_artist_names;
    delete[] g_song_durations;
    delete[] g_genres;
    g_song_names = song_names;
    g_artist_names = artist_names ;
    g_song_durations = song_durations;
    g_genres = genres;
    g_curr_size = size;
}
void readSongs(string filename);
void readSongs(string filename){
    ifstream fin(filename);
    if(fin.fail()){
        cerr << "File cannot opened for reading" << endl;
        exit(1);
    }
    string song_name, artist_name, genre, duration_prelim,junk;
    int duration;

    while (fin) {

        if(g_number_of_songs == g_curr_size)
        {
            allocateNew();
        }
        getline(fin, song_name, ':');
        getline(fin, artist_name, '-');
        getline(fin, genre, '-');
        getline(fin, duration_prelim, ' ');
        getline(fin, junk);

        duration = stoi(duration_prelim);

        g_song_names[g_number_of_songs] = song_name;
        g_artist_names[g_number_of_songs] = artist_name;
        g_song_durations[g_number_of_songs] = duration;
        g_genres[g_number_of_songs] = genre;

        g_number_of_songs++;
    }
    g_number_of_songs = g_number_of_songs-1;
    fin.close();

}
